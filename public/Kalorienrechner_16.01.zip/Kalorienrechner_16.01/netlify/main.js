'use strict';


/* Personal Body Input */
const SelectGender_Male_Container = document.querySelector(".SelectGender_Male_Container");
const SelectGender_Female_Container = document.querySelector(".SelectGender_Female_Container");
const MacronutrientCalc_KcalInput = document.querySelector("#MacronutrientCalc_KcalInput");

const CalorieCalc_AgeInput = document.querySelector("#CalorieCalc_AgeInput");
const CalorieCalc_WeightInput = document.querySelector("#CalorieCalc_WeightInput");
const CalorieCalc_HeightInput = document.querySelector("#CalorieCalc_HeightInput");

/*  Hours Input Fields */
let RestHours_Input = document.querySelector("#RestHours_Input");
let VeryLightHours_Input = document.querySelector("#VeryLightHours_Input");
let LightHours_Input = document.querySelector("#LightHours_Input");
let NormalHours_Input = document.querySelector("#NormalHours_Input");
let HeavyHours_Input = document.querySelector("#HeavyHours_Input");
let VeryHeavyHours_Input = document.querySelector("#VeryHeavyHours_Input");


/* Output Fields */
const TotalHours_Output = document.querySelector("#CalorieCalc_TotalHoursOutput");
const CalorieCalc_Base_Output = document.querySelector("#CalorieCalc_Base_Output");
const CalorieCalc_Total_Output = document.querySelector("#CalorieCalc_Total_Output");
const CalorieCalc_Btn = document.querySelector("#CalorieCalc_Btn");


/* Variables */
let Gender = "Female";
let Weight;
let Age;
let Height;
let Base;
let Total;
let RestHours;
let VeryLightHours;
let LightHours;
let NormalHours;
let HeavyHours;
let VeryHeavyHours;
let TotalHours;
/* let DidAlert = false; */


let MacronutrientCalc_Kcal;
const NutritionType_Select = document.querySelector("#NutritionType_Select");
const Carbohydrates_Output = document.querySelector("#Carbohydrates_Output");
const Protein_Output = document.querySelector("#Protein_Output");
const Fat_Output = document.querySelector("#Fat_Output");


const UpdateGender = (GenderInput) => {
    Gender = GenderInput;
    switch (Gender) {
        case "Male":
            SelectGender_Female_Container.classList.remove("SelectGender_Active");
            SelectGender_Male_Container.classList.add("SelectGender_Active");
            break;
        case "Female":
            SelectGender_Male_Container.classList.remove("SelectGender_Active");
            SelectGender_Female_Container.classList.add("SelectGender_Active");
            break;
    }
    if (Age !== undefined && Weight !== undefined && Height !== undefined) {
        CalculateCalorie();
    }
}


const CalculateCalorie = () => {
    /* Update Personal Body Information */
    Age = parseInt(CalorieCalc_AgeInput.value);
    Weight = parseInt(CalorieCalc_WeightInput.value);
    Height = parseInt(CalorieCalc_HeightInput.value);


    /* Check if Base Consumption can be Calculated */
    if (!isNaN(Age) || !isNaN(Weight) || !isNaN(Height)) {

        /* Calculate Base Consumption based on Gender */
        Gender === "Male" ?
            Base =
            66 + (13.7 * Weight) + (5 * Height) - (6.8 * Age) /* male */
            :
            Base =
            655 + (9.6 * Weight) + (1.7 * Height) - (4.7 * Age); /* female */

        if (!isNaN(Base)) { CalorieCalc_Base_Output.value = Base.toFixed(2) + " kcal"; }


        RestHours = parseInt(RestHours_Input.value);
        VeryLightHours = parseInt(VeryLightHours_Input.value);
        LightHours = parseInt(LightHours_Input.value);
        NormalHours = parseInt(NormalHours_Input.value);
        HeavyHours = parseInt(HeavyHours_Input.value);
        VeryHeavyHours = parseInt(VeryHeavyHours_Input.value);
        if (isNaN(parseInt(RestHours_Input.value))) {
            RestHours = 0;
            RestHours_Input.value = RestHours.toString();
        }
        else {
            RestHours = parseInt(RestHours_Input.value);
        }
        if (isNaN(parseInt(VeryLightHours_Input.value))) {
            VeryLightHours = 0;
            VeryLightHours_Input.value = VeryLightHours.toString();
        }
        else {
            VeryLightHours = parseInt(VeryLightHours_Input.value);
        }
        if (isNaN(parseInt(LightHours_Input.value))) {
            LightHours = 0;
            LightHours_Input.value = LightHours.toString();
        }
        else {
            LightHours = parseInt(LightHours_Input.value);
        }
        if (isNaN(parseInt(NormalHours_Input.value))) {
            NormalHours = 0;
            NormalHours_Input.value = NormalHours.toString();
        }
        else {
            NormalHours = parseInt(NormalHours_Input.value);
        }
        if (isNaN(parseInt(HeavyHours_Input.value))) {
            HeavyHours = 0;
            HeavyHours_Input.value = HeavyHours.toString();
        }
        else {
            HeavyHours = parseInt(HeavyHours_Input.value);
        }
        if (isNaN(parseInt(VeryHeavyHours_Input.value))) {
            VeryHeavyHours = 0;
            VeryHeavyHours_Input.value = VeryHeavyHours.toString();
        }
        else {
            VeryHeavyHours = parseInt(VeryHeavyHours_Input.value);
        }
        TotalHours = RestHours + VeryLightHours + LightHours + NormalHours + HeavyHours + VeryHeavyHours;

        if (!isNaN(TotalHours) && TotalHours === 24) {
            TotalHours_Output.value = TotalHours;
            switch (Gender) {
                case "Male":
                    Total =
                        Base / 24 *
                        (RestHours * 1 + (VeryLightHours * 1.2) + (LightHours * 1.3) +
                            (NormalHours * 1.5) + (HeavyHours * 1.7) +
                            (VeryHeavyHours * 2));
                    break;
                case "Female":
                    Total =
                        Base / 24 *
                        (RestHours * 0.95 + (VeryLightHours * 1.1) + (LightHours * 1.2) +
                            (NormalHours * 1.4) + (HeavyHours * 1.6) +
                            (VeryHeavyHours * 1.8));
                    break;
            }
            if (!isNaN(Total)) {
                CalorieCalc_Total_Output.value = Total.toFixed(2) + " kcal";
            }
        } else {
            /* if (!DidAlert) { 
                DidAlert = true;
            } */
                alert(`Es müssen 24 Std. sein! Es sind derzeit ${TotalHours} Std.`);
                TotalHours_Output.value = TotalHours;
        }
    } else {
        alert("Eingabe ungültig!");
    }
    /* Check if Total Consumption can be Calculated */
}


const CalculateMacronutrient = (MacronutrientCalc_Kcal) => {
    let proteinPercentage, carbPercentage, fatPercentage;
    switch (NutritionType_Select.value) {
        case "Standard":
            proteinPercentage = 0.25;
            carbPercentage = 0.5;
            fatPercentage = 0.25;
            break;
        case "Low Carb":
            proteinPercentage = 0.25;
            carbPercentage = 0.3;
            fatPercentage = 0.45;
            break;
        case "Low Fat":
            proteinPercentage = 0.25;
            carbPercentage = 0.5;
            fatPercentage = 0.25;
            break;
        default:
            console.log("Ungültige Ernährungsform");
            return;
    }
    /* Berechnung der Kalorien für jede Makronährstoffart */
    const proteinCalories = MacronutrientCalc_Kcal * proteinPercentage;
    const carbCalories = MacronutrientCalc_Kcal * carbPercentage;
    const fatCalories = MacronutrientCalc_Kcal * fatPercentage;
    /* Kalorien pro Gramm für jede Makronährstoffart */
    const caloriesPerGramProtein = 4.1;
    const caloriesPerGramCarb = 4.1;
    const caloriesPerGramFat = 9.3;
    /* Umrechnung von Kalorien in Gramm für jeden Makronährstoff */
    const proteinGrams = (proteinCalories / caloriesPerGramProtein).toFixed(2);
    const carbGrams = (carbCalories / caloriesPerGramCarb).toFixed(2);
    const fatGrams = (fatCalories / caloriesPerGramFat).toFixed(2);
    console.log(proteinGrams, carbGrams, fatGrams);


    Carbohydrates_Output.innerText = `${isNaN(carbGrams) ? "0" : carbGrams.replace(".",",")} g`;
    Protein_Output.innerText = `${isNaN(proteinGrams) ? "0" : proteinGrams.replace(".",",")} g`;
    Fat_Output.innerText = `${isNaN(fatGrams) ? "0" : fatGrams.replace(".",",")} g`;
}

NutritionType_Select.addEventListener("change", e => {
    CalculateMacronutrient(MacronutrientCalc_Kcal);
})
MacronutrientCalc_KcalInput.addEventListener("input", e => {
    MacronutrientCalc_Kcal = parseInt(e.target.value);
    CalculateMacronutrient(MacronutrientCalc_Kcal);
});